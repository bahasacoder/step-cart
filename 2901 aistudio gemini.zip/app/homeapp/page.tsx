"use client"
import React from 'react';
import { Provider, useSelector } from 'react-redux';
import { store, RootState } from '@/lib/store';
import Storefront from '@/components/StoreFront';

const HomeApp: React.FC = () => {
  return (
    <Provider store={store}>
      <Storefront />
    </Provider>
  );
};

export default HomeApp;
