
import { GoogleGenAI, Type } from "@google/genai";
import { CartItem } from "../types";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    // Fix: Using process.env.API_KEY directly as required by the latest Gemini SDK guidelines
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async getShoppingAdvice(cart: CartItem[]): Promise<string> {
    if (cart.length === 0) {
      return "Your cart is empty. I can help you find something great based on our latest tech gadgets!";
    }

    const cartSummary = cart.map(item => `${item.name} (${item.quantity}x)`).join(", ");
    const prompt = `I have the following items in my shopping cart: ${cartSummary}. 
    Act as an expert luxury tech shopping assistant. 
    1. Briefly comment on the combination of items.
    2. Suggest one complementary type of product I might need (don't mention specific brand names, just categories).
    3. Provide a one-sentence "Pro Tip" for getting the most out of these gadgets.
    Keep it concise and friendly.`;

    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });
      // Fix: response.text is a property, not a method
      return response.text || "I'm having trouble thinking of advice right now, but those look like great choices!";
    } catch (error) {
      console.error("Gemini Error:", error);
      return "I'm currently unable to assist with AI advice, but feel free to continue shopping!";
    }
  }
}

export const geminiService = new GeminiService();
